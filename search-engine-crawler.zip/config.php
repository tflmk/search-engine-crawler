<?php 

     $hostname = '';
     $username = '';
     $password = '';
     $db_name = '';

$conn = mysqli_connect($hostname, $username, $password, $db_name);

if (!$conn) {
    die('Connection failed: ' . mysqli_connect_error());
}

?>